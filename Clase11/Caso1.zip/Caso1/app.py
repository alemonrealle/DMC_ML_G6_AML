import streamlit as st
import requests
import pandas as pd
import matplotlib.pyplot as plt

# Configuración de la app
st.set_page_config(page_title="Clasificación de Riesgo de Crédito", layout="centered")
st.title("🔎 Clasificación de Riesgo de Crédito")
st.markdown("Ingresa los datos del cliente para estimar su nivel de **riesgo crediticio**.")

# Inputs del formulario
age = st.slider("🎂 Edad", 18, 70, 35)
income = st.number_input("💰 Ingreso mensual (USD)", min_value=0.0, step=100.0, value=2000.0)
loan = st.number_input("🏦 Monto solicitado del préstamo (USD)", min_value=0.0, step=500.0, value=5000.0)
term = st.selectbox("📆 Plazo del préstamo (meses)", [12, 24, 36, 48, 60])
loans_past = st.slider("📄 Créditos previos (últimos 5 años)", 0, 10, 2)
arrears = st.slider("❌ Cuotas vencidas actualmente", 0, 10, 0)
region = st.selectbox("📍 Región", ["Lima", "Arequipa", "Cusco", "Piura", "Trujillo"])

# Botón de predicción
if st.button("🔍 Evaluar Riesgo"):
    with st.spinner("Enviando solicitud al modelo..."):
        payload = {
            "age": age,
            "income": income,
            "loan_amount": loan,
            "term_months": term,
            "num_loans_last_5y": loans_past,
            "current_arrears": arrears,
            "region": region
        }

        try:
            r = requests.post("http://localhost:8000/predict_risk", json=payload)
            if r.status_code == 200:
                resultado = r.json()
                riesgo = resultado["riesgo_estimado"]
                probs = resultado["probabilidades"]

                st.subheader("🔐 Riesgo estimado:")
                if riesgo == "alto":
                    st.error("⚠️ Riesgo **ALTO**")
                elif riesgo == "medio":
                    st.warning("🟡 Riesgo **MEDIO**")
                else:
                    st.success("✅ Riesgo **BAJO**")

                # Mostrar gráfica de barras
                st.subheader("📊 Probabilidades por categoría de riesgo:")
                fig, ax = plt.subplots()
                labels = list(probs.keys())
                values = list(probs.values())
                ax.barh(labels, values, color=["red", "orange", "green"])
                ax.set_xlim(0, 1)
                st.pyplot(fig)

            else:
                st.error("❌ Error en la respuesta del servidor.")
        except Exception as e:
            st.error(f"❌ Error de conexión: {e}")


#uvicorn api:app --reload --port 8000
#streamlit run app.py
